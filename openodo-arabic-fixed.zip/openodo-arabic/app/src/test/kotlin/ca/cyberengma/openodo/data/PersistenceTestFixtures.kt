// SPDX-License-Identifier: GPL-3.0-only
package ca.cyberengma.openodo.data

import ca.cyberengma.openodo.core.model.FuelType
import ca.cyberengma.openodo.core.model.Vehicle
import ca.cyberengma.openodo.core.units.DistanceUnit
import ca.cyberengma.openodo.core.units.EnergyUnit
import ca.cyberengma.openodo.core.units.Metres
import ca.cyberengma.openodo.core.units.VolumeUnit

internal fun vehicle(
    id: Long = 0,
    name: String = "Metric Car",
    distance: DistanceUnit = DistanceUnit.KILOMETRES,
    volume: VolumeUnit = VolumeUnit.LITRES,
    energy: EnergyUnit = EnergyUnit.KILOWATT_HOURS,
    currency: String = "CAD",
    archived: Boolean = false,
) = Vehicle(
    id = id,
    name = name,
    make = "Make",
    model = "Model",
    year = 2024,
    vin = "VIN-1",
    photoFileName = "photo.jpg",
    distanceUnit = distance,
    volumeUnit = volume,
    energyUnit = energy,
    currency = currency,
    fuelType = FuelType.FUEL,
    manualOdometer = Metres(12_345),
    manualOdometerAt = 100,
    isArchived = archived,
    notes = "notes",
    createdAt = 1,
    updatedAt = 2,
)
