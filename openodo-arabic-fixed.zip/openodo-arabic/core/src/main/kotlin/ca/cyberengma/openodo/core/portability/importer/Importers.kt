// SPDX-License-Identifier: GPL-3.0-only
package ca.cyberengma.openodo.core.portability.importer

import ca.cyberengma.openodo.core.model.*
import ca.cyberengma.openodo.core.money.Money
import ca.cyberengma.openodo.core.money.UnitPrice
import ca.cyberengma.openodo.core.portability.*
import ca.cyberengma.openodo.core.portability.csv.Rfc4180
import ca.cyberengma.openodo.core.units.DistanceUnit
import ca.cyberengma.openodo.core.units.Metres
import ca.cyberengma.openodo.core.units.Millilitres
import java.io.StringReader
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

private val drivvoDate = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

private val fuelioDateFormats = listOf(
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"),
)

private fun parseFuelioDate(text: String): LocalDate? {
    runCatching { return LocalDate.parse(text) }
    for (format in fuelioDateFormats) {
        runCatching { return LocalDateTime.parse(text, format).toLocalDate() }
    }
    return null
}

object FuelioImporter {
    fun import(source: String): ImportResult {
        val rows = Rfc4180.read(StringReader(source)).toList()
        val vehicleRow = rows.getOrNull(2) ?: return ImportResult(PortabilityDomain(), listOf(ImportNote(1, ImportLevel.SKIP, "MISSING_VEHICLE", "vehicle section missing")))
        val distanceUnit = fuelioDistanceUnit(vehicleRow.getOrNull(2))
        val vehicle = Vehicle(1, vehicleRow[0], vehicleRow.getOrElse(9) { "" }, vehicleRow.getOrElse(10) { "" }, vehicleRow.getOrElse(11) { "0" }.toIntOrNull() ?: 0, null, null, distanceUnit, ca.cyberengma.openodo.core.units.VolumeUnit.LITRES, ca.cyberengma.openodo.core.units.EnergyUnit.KILOWATT_HOURS, "USD", FuelType.FUEL, null, null, false, vehicleRow.getOrNull(1)?.ifBlank { null }, 0, 0)

        val entries = mutableListOf<FuelEntry>()
        val expenses = mutableListOf<ExpenseRecord>()
        val recordTypes = mutableListOf<RecordType>()
        val costCategoryNames = mutableMapOf<Long, String>()
        val typeIds = mutableMapOf<String, Long>()
        val notes = mutableListOf<ImportNote>()
        var nextTypeId = 1L

        var section: String? = null
        var line = 0
        for (row in rows) {
            line++
            if (row.isEmpty()) continue
            when (row.firstOrNull()) {
                "## Vehicle" -> section = "vehicle"
                "## Log" -> section = "log"
                "## CostCategories" -> section = "cost-categories"
                "## Costs" -> section = "costs"
                "## Category" -> section = "category"
            }
            when (section) {
                "cost-categories" -> {
                    val id = row.getOrNull(0)?.toLongOrNull() ?: continue
                    val name = row.getOrNull(1)?.takeIf { it.isNotBlank() } ?: continue
                    costCategoryNames[id] = name
                }
                "log" -> {
                    if (row.size < 18 || row[0].isBlank() || row[0] == "Data") continue
                    val date = parseFuelioDate(row[0]) ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_DATE", "date is not ISO yyyy-MM-dd or a supported datetime"); continue
                    }
                    val odo = row[1].toBigDecimalOrNull() ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_ODOMETER", "odometer is not numeric"); continue
                    }
                    val litres = row[2].toBigDecimalOrNull() ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_VOLUME", "fuel volume is not numeric"); continue
                    }
                    val volumePrice = row[13].toBigDecimalOrNull()
                    val odometer = fuelioOdometer(odo, distanceUnit)
                    entries += FuelEntry(entries.size + 1L, 1, date, odometer, FuelKind.LIQUID, Millilitres.litres(litres), null, volumePrice?.let { UnitPrice((it * java.math.BigDecimal(1_000)).toLong(), "USD") }, Money((row[4].toBigDecimalOrNull()?.multiply(java.math.BigDecimal(100))?.toLong() ?: 0L), "USD"), "", row[3] == "1", row[10] == "1", row[8].ifBlank { null }, null, row[9].ifBlank { null }, 0, 0)
                }
                "costs" -> {
                    if (row.size < 6 || row[0].isBlank() || row[0] == "CostTitle") continue
                    if (row.getOrNull(14) == "1") continue // isIncome
                    val date = parseFuelioDate(row[1]) ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_DATE", "cost date is invalid"); continue
                    }
                    val odo = row[2].toBigDecimalOrNull() ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_ODOMETER", "cost odometer is not numeric"); continue
                    }
                    val cost = row[5].toBigDecimalOrNull() ?: run {
                        notes += ImportNote(line, ImportLevel.SKIP, "INVALID_COST", "cost is not numeric"); continue
                    }
                    val costTypeId = row[3].toLongOrNull()
                    val typeName = (costTypeId?.let { costCategoryNames[it] } ?: "").ifBlank { "Other" }
                    val typeId = typeIds.getOrPut(typeName) {
                        val id = nextTypeId++
                        recordTypes += RecordType(id, guessCategory(typeName), typeName, false)
                        id
                    }
                    val odometer = fuelioOdometer(odo, distanceUnit)
                    expenses += ExpenseRecord(expenses.size + 1L, 1, guessCategory(typeName), date, odometer, null, PerformedBy.SELF, null, null, null, row.getOrNull(4)?.ifBlank { null }, listOf(ExpenseLineItem(typeId, Money((cost.multiply(java.math.BigDecimal(100))).toLong(), "USD"))), 0, 0)
                }
            }
        }
        return ImportResult(PortabilityDomain(vehicles = listOf(vehicle), recordTypes = recordTypes, fuelEntries = entries, expenseRecords = expenses), notes)
    }
}

private fun fuelioDistanceUnit(code: String?): DistanceUnit = when (code) {
    "1" -> DistanceUnit.MILES
    else -> DistanceUnit.KILOMETRES
}

private fun fuelioOdometer(amount: java.math.BigDecimal, unit: DistanceUnit): Metres = when (unit) {
    DistanceUnit.MILES -> Metres.miles(amount)
    else -> Metres.kilometres(amount)
}

object DrivvoImporter {
    fun import(source: String): ImportResult {
        val rows = Rfc4180.read(StringReader(source)).toList()
        val notes = mutableListOf<ImportNote>()
        val vehicleHeader = rows.indexOfFirst { it.firstOrNull() == "Vehicle Name" && it.getOrNull(1) == "Active" }
        val vehicleRow = rows.getOrNull(vehicleHeader + 1)
        val vehicle = vehicleRow?.let { Vehicle(1, it[0], it.getOrElse(3) { "" }, it.getOrElse(4) { "" }, it.getOrElse(6) { "0" }.toIntOrNull() ?: 0, null, null, ca.cyberengma.openodo.core.units.DistanceUnit.KILOMETRES, ca.cyberengma.openodo.core.units.VolumeUnit.LITRES, ca.cyberengma.openodo.core.units.EnergyUnit.KILOWATT_HOURS, "USD", FuelType.FUEL, null, null, it.getOrElse(1) { "Yes" } != "Yes", it.getOrNull(11)?.ifBlank { null }, 0, 0) }

        val fuels = mutableListOf<FuelEntry>()
        val expenses = mutableListOf<ExpenseRecord>()
        val recordTypes = mutableListOf<RecordType>()
        val typeIds = mutableMapOf<String, Long>()

        var section: String? = null
        var nextTypeId = 1L
        var line = 0
        for (row in rows) {
            line++
            if (row.isEmpty()) continue
            when {
                row.firstOrNull() == "#Vehicle" -> section = "vehicle"
                row.firstOrNull() == "#Refueling" -> { section = "refueling"; notes += ImportNote(line, ImportLevel.INFO, "DRIVVO_MISSED_DEFAULT_FALSE", "Drivvo has no missed-fill column; imported as false") }
                row.firstOrNull() == "#Expense" -> section = "expense"
                row.firstOrNull() == "#Service" -> section = "service"
                row.firstOrNull() == "Vehicle Name" -> {
                    section = when {
                        row.getOrNull(1) == "Active" -> "vehicle"
                        row.getOrNull(4)?.contains("expense", ignoreCase = true) == true -> "expense"
                        row.getOrNull(4)?.contains("service", ignoreCase = true) == true -> "service"
                        row.getOrNull(1) == "Odometer (km)" -> "refueling"
                        else -> null
                    }
                }
                section == "refueling" && row.size >= 7 && row[0].isNotBlank() -> {
                    val date = runCatching { LocalDate.parse(row[2], drivvoDate) }.getOrNull()
                    val odo = row[1].toLongOrNull()
                    val volume = row[6].toBigDecimalOrNull()
                    if (date == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_DATE", "Drivvo date is invalid"); continue }
                    if (odo == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_ODOMETER", "Drivvo odometer is invalid"); continue }
                    if (volume == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_VOLUME", "Drivvo volume is invalid"); continue }
                    fuels += FuelEntry(fuels.size + 1L, 1, date, Metres(odo * 1_000), FuelKind.LIQUID, Millilitres.litres(volume), null, UnitPrice((row[4].toBigDecimalOrNull()?.multiply(java.math.BigDecimal(1000))?.toLong() ?: 0), "USD"), Money((row[5].toBigDecimalOrNull()?.multiply(java.math.BigDecimal(100))?.toLong() ?: 0), "USD"), row.getOrElse(3) { "Fuel" }, row.getOrElse(7) { "No" } == "Yes", false, row.getOrNull(25)?.ifBlank { null }, null, row.getOrNull(29)?.ifBlank { null }, 0, 0)
                }
                (section == "expense" || section == "service") && row.size >= 6 && row[0].isNotBlank() -> {
                    val date = runCatching { LocalDate.parse(row.getOrElse(2) { "" }, drivvoDate) }.getOrNull()
                    val odo = row[1].toLongOrNull()
                    val cost = row[3].toBigDecimalOrNull()
                    if (date == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_DATE", "Drivvo date is invalid"); continue }
                    if (odo == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_ODOMETER", "Drivvo odometer is invalid"); continue }
                    if (cost == null) { notes += ImportNote(line, ImportLevel.SKIP, "INVALID_COST", "Drivvo cost is invalid"); continue }
                    val typeName = row.getOrElse(4) { "" }.ifBlank { "Other" }
                    val typeId = typeIds.getOrPut(typeName) {
                        val id = nextTypeId++
                        recordTypes += RecordType(id, guessCategory(typeName), typeName, false)
                        id
                    }
                    expenses += ExpenseRecord(expenses.size + 1L, 1, guessCategory(typeName), date, Metres(odo * 1_000), null, PerformedBy.SHOP, row.getOrNull(5)?.ifBlank { null }, null, null, row.getOrNull(9)?.ifBlank { null }, listOf(ExpenseLineItem(typeId, Money((cost.multiply(java.math.BigDecimal(100))).toLong(), "USD"))), 0, 0)
                }
            }
        }
        return ImportResult(PortabilityDomain(vehicles = listOfNotNull(vehicle), recordTypes = recordTypes, fuelEntries = fuels, expenseRecords = expenses), notes)
    }
}

private fun guessCategory(type: String): RecordCategory {
    val t = type.lowercase()
    return when {
        "upgrade" in t || "tuning" in t -> RecordCategory.UPGRADE
        "service" in t || "maintenance" in t -> RecordCategory.SERVICE
        "repair" in t || "replacement" in t || "parts" in t || "brake" in t || "tire" in t || "tyre" in t -> RecordCategory.REPAIR
        else -> RecordCategory.OTHER
    }
}
